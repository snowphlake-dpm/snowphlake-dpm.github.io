import numpy as np 
import pandas as pd 
import statsmodels.formula.api as sm

class correct_confounders():

    def __init__(self,factors,biomarker_list):
        
        str_confounders=''
        for j in range(len(factors)):
            str_confounders = str_confounders + '+' + factors[j] 
        str_confounders=str_confounders[1:]

        self.factors = factors
        self.factors_concatenated = str_confounders
        self.biomarker_list = biomarker_list

        self.means = dict.fromkeys(factors)

        self.stats_models = dict.fromkeys(biomarker_list)
        
    def fit(self, data):

        for f in self.factors:
            self.means[f] = np.nanmean(data[f].values)
        ## Multiple linear regression

        for b in self.biomarker_list:
            str_formula = b + '~' + self.factors_concatenated
            result = sm.ols(formula=str_formula, data=data[self.factors+[b]]).fit()
            self.stats_models[b] = result.params

    def predict(self,data):

        data_corrected = data.copy(deep=True)
        ## Correction for the confounding factors
        Deviation = data[self.factors].copy(deep=True)
        for f in self.factors:
            Deviation[f]=(data[f] - self.means[f])

        for b in self.biomarker_list:
            betai=self.stats_models[b].values
            betai_slopes = betai[1:]
            CorrectionFactor = np.dot(Deviation.values,betai_slopes)
            data_corrected[b] = data[b] - CorrectionFactor

        return data_corrected