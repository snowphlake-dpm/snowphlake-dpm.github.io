import pandas as pd 
import numpy as np 

def map(data,list_biomarkers,additional_fields=[]):
    list_biomarkers.remove('CSF')
    list_biomarkers.remove('BrainSegVol')
    list_biomarkers.remove('BrainSegVolNotVent')
    list_biomarkers.remove('TotalGrayVol')

    list_nonbiomarkers = ['Age','Sex','Diagnosis', 'eTIV', 'ID'] + additional_fields

    list_imaging_cortical = ['Temporal_lobe','Superior_frontal_gyrus','Middle_frontal_gyrus','Inferior_frontal_gyrus',
                'Gyrus_rectus','Orbitofrontal_gyri','Precentral_gyrus','Postcentral_gyrus','Superior_parietal_gyrus',
                'Inferolateral_remainder_of_parietal_lobe','Lateral_remainder_of_occipital_lobe','Cuneus','Lingual_gyrus',
                'Insula','Gyrus_cinguli_anterior_part','Gyrus_cinguli_posterior_part','Parahippocampal_and_ambient_gyri']

    list_subcortical = ['Thalamus','Caudate','Putamen','Pallidum','Hippocampus','Amygdala','Accumbens-area']

    org_subcortical_left = ['Left-Thalamus', 'Left-Caudate', 'Left-Putamen', 'Left-Pallidum', 'Left-Hippocampus','Left-Amygdala','Left-Accumbens-area']
    org_subcortical_right = ['Right-Thalamus','Right-Caudate','Right-Putamen','Right-Pallidum','Right-Hippocampus','Right-Amygdala','Right-Accumbens-area']

    org_cortical_mapping_left = [['lh_bankssts_volume','lh_transversetemporal_volume','lh_superiortemporal_volume','lh_temporalpole_volume','lh_entorhinal_volume','lh_middletemporal_volume','lh_inferiortemporal_volume','lh_fusiform_volume'],
    ['lh_superiorfrontal_volume','lh_frontalpole_volume'],
    ['lh_caudalmiddlefrontal_volume','lh_rostralmiddlefrontal_volume'],
    ['lh_parsopercularis_volume','lh_parsorbitalis_volume','lh_parstriangularis_volume'],
    ['lh_medialorbitofrontal_volume'],
    ['lh_lateralorbitofrontal_volume'],
    ['lh_precentral_volume','lh_paracentral_volume'],
    ['lh_postcentral_volume'],
    ['lh_superiorparietal_volume','lh_precuneus_volume'],
    ['lh_inferiorparietal_volume','lh_supramarginal_volume'],
    ['lh_lateraloccipital_volume'],
    ['lh_cuneus_volume','lh_pericalcarine_volume'],
    ['lh_lingual_volume'],
    ['lh_insula_volume'],
    ['lh_caudalanteriorcingulate_volume','lh_rostralanteriorcingulate_volume'],
    ['lh_posteriorcingulate_volume','lh_isthmuscingulate_volume'],
    ['lh_parahippocampal_volume']]

    org_cortical_mapping_right = [['rh_bankssts_volume','rh_transversetemporal_volume','rh_superiortemporal_volume','rh_temporalpole_volume','rh_entorhinal_volume','rh_middletemporal_volume','rh_inferiortemporal_volume','rh_fusiform_volume'],
    ['rh_superiorfrontal_volume','rh_frontalpole_volume'],
    ['rh_caudalmiddlefrontal_volume','rh_rostralmiddlefrontal_volume'],
    ['rh_parsopercularis_volume','rh_parsorbitalis_volume','rh_parstriangularis_volume'],
    ['rh_medialorbitofrontal_volume'],
    ['rh_lateralorbitofrontal_volume'],
    ['rh_precentral_volume','rh_paracentral_volume'],
    ['rh_postcentral_volume'],
    ['rh_superiorparietal_volume','rh_precuneus_volume'],
    ['rh_inferiorparietal_volume','rh_supramarginal_volume'],
    ['rh_lateraloccipital_volume'],
    ['rh_cuneus_volume','rh_pericalcarine_volume'],
    ['rh_lingual_volume'],
    ['rh_insula_volume'],
    ['rh_caudalanteriorcingulate_volume','rh_rostralanteriorcingulate_volume'],
    ['rh_posteriorcingulate_volume','rh_isthmuscingulate_volume'],
    ['rh_parahippocampal_volume']]

    data_mapped = pd.DataFrame(columns = list_nonbiomarkers + list_subcortical + list_imaging_cortical)

    for l in list_nonbiomarkers:
        data_mapped[l] = data[l].copy()

    for c,l,r in zip(list_subcortical,org_subcortical_left,org_subcortical_right):
        data_mapped[c] = data[l] + data[r]

    for c,l,r in zip(list_imaging_cortical , org_cortical_mapping_left, org_cortical_mapping_right):
        data_mapped[c] = np.sum(data[l].values,axis=1)+np.sum(data[r].values,axis=1)

    BiomarkersList = list_subcortical + list_imaging_cortical

    data_mapped = data_mapped.rename(columns={'Accumbens-area':'Accumbens'})
    BiomarkersList[6] = 'Accumbens'

    return data_mapped, BiomarkersList